#! /bin/sh

ninjanumgen ttbarh.frm --nlegs 5 --rank 4 --diagname TTbarHDiagram \
    -o ttbarh_num.cc
